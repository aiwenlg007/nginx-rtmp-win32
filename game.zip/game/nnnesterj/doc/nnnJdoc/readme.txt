
                 "NNNesterJ" - (nesterJ + some functions)

-----------
This software adds some functions to nesterJ.

NNNesterJ does not exist without nester, unoffical nester, and nesterJ.

Please use it in appreciation of all of Mr. Darren Ranalli, Mr. Takeda, Mr. Screws, Mr. mikami kana, and the persons engaged in these.

Please stop NNNesterJ being questioned Mr. Darren Ranalli, Mr. Takeda, Mr. Screw, Mr. Mikami kana.


----The main function of NNNesterJ----

-Screen shot preservation with PNG.
-Auto Fire(A&B Button Only)
-Launcher
   "Nesdbase.dat" of the NesToy attachment is necessary to use the data base.
   "Ingredients.dat" attached to FDSSpray etc. is necessary for FDS.
 Please the game name etc. are displayed in the launcher and check both "ROM Info Scan" of setting and "CRC Scan And Database". 
 If "List update" is executed afterwards, is displayed. 
